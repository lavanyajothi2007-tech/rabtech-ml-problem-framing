# Responsible Data Card — Customer Churn

## Dataset purpose
The dataset is intended for a small supervised-learning exercise to support a **customer-churn prioritization** decision. It must not be used by itself to automatically cancel service, deny benefits, change prices, or make other high-impact customer decisions. The template requires the decision supported and decisions prohibited to be documented. fileciteturn0file0L3-L4

## Provenance and permission
Source: RabTech Academy starter file `customer-churn-training.csv`.

The supplied CSV contains 12 rows and the fields listed below. The file does **not** provide provenance details, collection dates, consent records, licensing terms, or data-owner information. Therefore, permission/consent status is **unknown from the supplied source** and must be verified before real-world use. The data-card template specifically requires provenance, authorized use, and consent/licensing restrictions to be documented. fileciteturn0file0L6-L7

## Population and representation
The file contains 12 customer records:
- Basic: 5
- Standard: 4
- Pro: 3
- Churned: 5 (41.7%)
- Not churned: 7 (58.3%)

This is a tiny starter dataset and should not be assumed to represent the broader customer population. The dataset does not provide demographic or other population coverage information, so representativeness and subgroup imbalance cannot be established. The template calls for represented/missing groups and sampling limitations to be documented. fileciteturn0file0L9-L10

## Features and target
- `customer_id`: identifier; exclude from model training.
- `tenure_months`: numeric feature; months of tenure.
- `support_tickets`: numeric feature; number of support tickets.
- `monthly_spend_inr`: numeric feature; monthly spend in INR.
- `last_login_days`: numeric feature; days since last login.
- `plan_type`: categorical feature with Basic, Standard, and Pro.
- `churned`: binary target label (1/0).

**Sensitive attributes:** none are explicitly supplied.

**Sensitive proxies:** `plan_type`, spending, tenure, support activity, and login recency could correlate with customer segments or circumstances. Proxy risk should therefore be tested before production use.

**Leakage risk:** feature timestamps are absent. Any value recorded after the prediction point, or derived from post-churn activity, could leak the target. The template explicitly requires leakage to be considered. fileciteturn0file0L12-L13

## Quality checks
- Missing values: 0
- Duplicate rows: 0
- Target balance: 7 not churned / 5 churned
- Train/test separation: **not performed for the baseline**.
- Outliers: no automated outlier rule was applied because the dataset is too small for a reliable production-quality outlier policy.
- Data volume: 12 rows; insufficient for a trustworthy production model.

The template requires missingness, duplicates, outliers, class balance, and train/test separation to be recorded. fileciteturn0file0L15-L16

## Risks and safeguards
| Risk | Potential harm | Safeguard |
|---|---|---|
| Sampling bias | Poor performance on real customers | Collect larger, representative historical data |
| Privacy/permission uncertainty | Unauthorized use of customer information | Verify provenance, consent, and licensing before operational use |
| False positive | Unnecessary/annoying retention contact | Use precision and intervention-cost analysis; cap outreach |
| False negative | Missed retention opportunity | Monitor churn recall and review high-risk misses |
| Leakage | Unrealistically high validation performance | Use point-in-time feature definitions and temporal validation |
| Proxy discrimination | Unequal treatment of customer groups | Conduct subgroup/error analysis where lawful and appropriate |
| Misuse | Model score treated as fact | Human review; use as prioritization only |
| Tiny sample | Unstable model estimates | Do not deploy; obtain substantially more labeled data |

These categories align with the responsible-data-card requirement to address bias, privacy, misuse, false positives, false negatives, and mitigations. fileciteturn0file0L18-L19

## Intended evaluation
**Baseline:** majority-class classifier predicting `churned = 0`.

**Required model measures before training:** recall, precision, PR-AUC, calibration, and error analysis.

**Business evaluation:** incremental retention/conversion, cost per retained customer, and intervention side effects.

**Fairness:** where appropriate and legally permissible, compare error rates/calibration across relevant customer groups. No protected-group fields are supplied in this starter dataset, so a fairness assessment cannot currently be completed.

The template requires baseline, performance, calibration, fairness, and error-analysis measures to be named before training. fileciteturn0file0L21-L22

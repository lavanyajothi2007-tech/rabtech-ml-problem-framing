# Risk Register — Customer Churn ML

| ID | Risk | Likelihood | Impact | Mitigation | Owner / next step |
|---|---|---|---|---|---|
| R1 | Dataset too small for reliable ML | High | High | Do not deploy; collect more historical labels | Data/ML team |
| R2 | Unknown provenance/consent | Medium | High | Verify source, permission and licensing | Data owner |
| R3 | Target/feature leakage | Medium | High | Define point-in-time features; temporal validation | ML engineer |
| R4 | False positives annoy customers | Medium | Medium | Track precision and outreach complaints; cap interventions | Retention team |
| R5 | False negatives miss retention opportunities | Medium | High | Track churn recall; review missed churn cases | ML/retention team |
| R6 | Sampling/representation bias | High | High | Compare with production population and subgroup performance | Data science |
| R7 | Model score treated as certainty | Medium | High | Human review and clear usage policy | Product owner |
| R8 | Proxy discrimination | Medium | High | Review plan/spend/behavior proxies and subgroup errors | Responsible AI owner |

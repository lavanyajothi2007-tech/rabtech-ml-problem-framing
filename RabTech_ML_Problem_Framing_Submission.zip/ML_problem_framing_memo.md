# ML Problem-Framing Memo — Customer Churn

## 1. Decision
**Decision to support:** identify customers who may churn so a retention team can prioritize an appropriate, non-punitive retention action.

**Decision the model must NOT make:** automatic cancellation, denial of service, pricing changes, eligibility decisions, or any high-impact decision about a customer. A prediction is a prioritization signal, not a final decision.

## 2. Prediction target
- **Target:** `churned`
- **Positive class:** `1` = churned
- **Negative class:** `0` = not churned
- **Unit of observation:** one customer record/snapshot.
- **Action window:** **proposed 30 days after the prediction snapshot**. This is a framing assumption because the supplied dataset does not specify a real operational action window.

## 3. Is ML justified?
**Conditionally, for prioritization only.** A churn prediction model can be useful if the business has a retention intervention and enough historical data to evaluate whether predictions improve retention compared with a simple rule.

For this starter dataset, ML should **not** be treated as production-ready. It contains only 12 labeled rows, so a train/test result would be highly unstable. The immediate goal is responsible problem framing and a transparent baseline.

## 4. Non-ML baseline
Use a **majority-class baseline**: predict `0` (not churned) for every customer because the supplied data contains 7 non-churned and 5 churned records.

- Records: 12
- Non-churned: 7
- Churned: 5
- Churn rate: 41.7%
- Baseline accuracy: 58.3%
- Baseline recall for churn: 0.0%
- Baseline precision for churn: undefined/0 because no positive predictions are made.

## 5. Features
Candidate predictors in the supplied CSV:
- `tenure_months`
- `support_tickets`
- `monthly_spend_inr`
- `last_login_days`
- `plan_type`

Exclude `customer_id` from model features because it is an identifier rather than a behavioral predictor.

## 6. Metrics and error costs
### Business metrics
- Retention intervention acceptance/conversion rate.
- Incremental retention among contacted customers versus an appropriate control group.
- Cost per retained customer.
- Customer complaints or opt-outs caused by interventions.

### Model metrics
- **Recall for churn:** important because false negatives can miss customers who need support.
- **Precision for churn:** important because false positives can waste outreach resources and annoy customers.
- **PR-AUC:** useful when positive cases are less common.
- **Calibration:** predicted probabilities should correspond reasonably to observed churn rates.

### Explicit error costs
- **False positive:** contacting a customer who would not churn → outreach cost, possible annoyance, and trust impact.
- **False negative:** failing to prioritize a customer who would churn → missed retention opportunity and possible revenue loss.
- The exact rupee costs are **not supplied**, so they should be estimated with the business before deployment. Do not invent them.

## 7. Leakage check
Potential leakage must be assessed by ensuring every feature is available **before** the prediction decision. In particular, any field recorded after churn or created from post-churn activity must not be used.

The supplied dataset alone does not document feature timestamps, so leakage cannot be fully ruled out from this file.

## 8. Deployment guardrail
Do not deploy from this 12-row dataset. First obtain a larger, time-ordered historical dataset, define the intervention and action window, establish a temporal holdout, quantify false-positive/false-negative costs, and perform error/fairness analysis.
